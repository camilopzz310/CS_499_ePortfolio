//============================================================================
// Name        : ProjectTwo.cpp
// Author      : Camila Lopez
// Version     : 1.0
// Description : A hashtable data structure was used to develop code to read a file
//               and create a menu to load a data structure, print a course list,
//               print course information, and exit the program.
//============================================================================

#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>
#include <sstream>
#include <set>
using namespace std;

// Define the Course Structure
struct Course {
    string courseNumber;
    string courseTitle;
    unordered_map<string, bool> prerequisites;
};

// Instead of using a vector to store the information an unordered_map is used
// Declare a hash table that stores courses
unordered_map<string, Course> courses;

// Create a function that counts the number of prerequisites
int numPrerequisiteCourses(unordered_map<string, Course>& courses, Course& c) {

    // Set totalPrerequisites as the course prerequisites
    set<string> totalPrerequisites;
    for (const auto& prereq : c.prerequisites) {
        totalPrerequisites.insert(prereq.first);
    }

    // For each prerequisite in totalPrerequisites
    for (const auto& prereq : totalPrerequisites) {
        // Find the course in the hash table
        // To search through the hashtable use the function find
        auto it = courses.find(prereq);
        if (it != courses.end()) {
            // For each prerequisite of the found course
            for (const auto& subPrereq : it->second.prerequisites) {
                // Add the course prerequisites to total prerequisites
                totalPrerequisites.insert(subPrereq.first);
            }
        }
    }
    // Return the size of the total prerequisites
    return totalPrerequisites.size();
}

// Create a function that prints the course information
void printCourseInformation(unordered_map<string, Course>& courses, const string& courseNumber) {
    // Find the course in the hash table
     // To search through the hashtable use the function find
    auto it = courses.find(courseNumber);

    // If the course is found
    if (it != courses.end()) {
        // Print course number
        cout << it->second.courseNumber;

        // Print course title
        cout << ", " << it->second.courseTitle << endl;

        // Print list of prerequisites
        cout << "Prerequisites: ";
        for (const auto& prereq : it->second.prerequisites) {
            // Print the prerequisites
            cout << prereq.first << ", ";
        }
        cout << endl;
    }
    // Else print course not found
    else {
        cout << "Course not found!" << endl;
    }
}

// Create a function to load courses
void loadCourses(const string& filename) {

    // Declare variable
    string line;

    // Print loading txt file
    cout << "Loading TXT file..." << filename << endl;

    // Create an ifstream object called file that opens the filename
    ifstream file(filename);

    // If file failed to open
    if (!file) {
        // Print failed to open
        cout << "Failed to open file." << endl;
        // Return to cases
        return;
    }

    // Create a while loop that reads each line in the file
    while (getline(file, line)) {
        // Create an object stringstream ss for the line
        stringstream ss(line);

        // Declare course object course to store information
        Course course;

        // Declare variable token
        string token;

        // Get the course number and title using the first two tokens separated by commas
        getline(ss, token, ',');
        course.courseNumber = token;

        getline(ss, token, ',');
        course.courseTitle = token;

        // For the rest of the tokens add them to the prerequisites of the course
        while (getline(ss, token, ',')) {
            course.prerequisites[token] = true;
        }

        // Add the course to the hash table
        courses[course.courseNumber] = course;
    }

    // Close file
    file.close();

    // Print file loaded successfully
    cout << "File loaded successfully!" << endl;
}

// Create a function that compares courses
bool compareCourses(const Course& course1, const Course& course2) {
    // Return the expression
    return course1.courseNumber < course2.courseNumber;
}

// Create the function sortCoursesAlphanumeric
set<string> sortCoursesAlphanumeric(unordered_map<string, Course>& courses) {
    // Create a set to automatically sort course numbers
    set<string> sortedCourses;
    for (const auto& pair : courses) {
        sortedCourses.insert(pair.first);
    }
    return sortedCourses;
}

// Create a function to print course list
void printCourseList(unordered_map<string, Course>& courses) {
    // Call the function sortCoursesAlphanumeric
    set<string> sortedCourses = sortCoursesAlphanumeric(courses);

    // For each course number in the sorted set
    for (const string& courseNumber : sortedCourses) {
        // Print course number and title
        cout << courses[courseNumber].courseNumber << ", " << courses[courseNumber].courseTitle << endl;
    }
}

// Main function
int main() {
    // Declare variables
    int choice;
    bool isDataLoaded = false;
    string filename;

    // Print menu
    cout << "Welcome to the course planner." << endl;
    cout << "1. Load Data Structure." << endl;
    cout << "2. Print Course List." << endl;
    cout << "3. Print Course." << endl;
    cout << "9. Exit" << endl;

    // Create a while loop
    while (true) {
        // Ask user for their menu option and store it in variable choice
        cout << "What would you like to do? ";
        cin >> choice;

        // Create case statements based on each menu option
        switch (choice) {
            // If menu option 1 is chosen
        case 1:
            // Set the filename
            cout << "Input filename with '.txt' included in the end: ";
            cin >> filename;

            // Call the function loadCourses
            loadCourses(filename);

            // Set isDataLoaded to true
            isDataLoaded = true;

            // Break
            break;

            // If menu option 2 is chosen
        case 2:
            // If isDataLoaded true
            if (isDataLoaded) {
                // Call the function printCourseList()
                printCourseList(courses);
            }
            // Else print for the user to load the data first
            else {
                cout << "Please load the data from the file first. Select Option 1." << endl;
            }

            // Break
            break;

            // If the menu option is 3
        case 3:
            // If isDataLoaded true
            if (isDataLoaded) {
                // Declare variable
                string courseNumber;

                // Prompt user to enter a course number and store it in courseNumber
                cout << "Enter course number: ";
                cin >> courseNumber;

                // Call the function printCourseInformation
                printCourseInformation(courses, courseNumber);
            }
            // Else print for the user to load the data first
            else {
                cout << "Please load the data from the file first. Select Option 1." << endl;
            }

            // Break
            break;

            // If the menu option is 9
        case 9:
            // Print thank you for using course planner and exit
            cout << "Thank you for using the course planner!" << endl;
            return 0;

            // If the choice is anything other than the previous options
        default:
            // Print wrong input
            cout << "Wrong input" << endl;

            // Break
            break;
        }
        cout << endl;
    }

    return 0;
}
