//============================================================================
// Name        : ProjectTwo.cpp
// Author      : Camila Lopez
// Version     : 1.0
// Description : A vector data structure was used to develop code to read a file
//               and create a menu to load a data structure, print a course list,
//               print course information, and exit the program.
//============================================================================

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <sstream>
using namespace std;

// Define the Course Structure
struct Course {
    string courseNumber;
    string courseTitle;
    vector<string> prerequisites;
};

// Declare a vector that stores courses
vector<Course> courses;

// Create a function that counts the number of prerequisites
int numPrerequisiteCourses(vector<Course>& courses, Course& c) {

    // Set totalPrerequisites as the course prerequisites
    vector<string> totalPrerequisites = c.prerequisites;
    
    // For i is 0 to the size of totalPrerequisites vector
    for (int i = 0; i < totalPrerequisites.size(); i++) {
        
        // For j is 0 to te courses vector size
        for (int j = 0; j < courses.size(); j++) {

            // If the courseNumber in the vector courses is the same as the courseNumber in the vector totalPrerequisites
            if (courses[j].courseNumber == totalPrerequisites[i]) {

                // For k = 0 to the size of the current course prerequisites
                for (int k = 0; k < courses[j].prerequisites.size(); k++) {
                    
                    // Add the course prerequisites to total prerequisites
                    totalPrerequisites.push_back(courses[j].prerequisites[k]);
                }
            }
        }
    }
    // Return the size of the total prerequisites
    return totalPrerequisites.size();
}

// Create a function that finds the course index
int findCourseIndex(vector<Course>& courses, string courseNumber) {

    // For i is 0 to courses vector size
    for (int i = 0; i < courses.size(); i++) {

        // If the course numbers are the same
        if (courses[i].courseNumber == courseNumber) {

            // Return the index
            return i;
        }
    }

    // Else return -1
    return -1;
}

// Create a function that prints the course information
void printCourseInformation(vector<Course>& courses, string courseNumber) {

    // Call the function findCourseIndex to find the index of the course number and set it to courseIndex 
    int courseIndex = findCourseIndex(courses, courseNumber);

    // If courseIndex is not -1
    if (courseIndex != -1) {

        // Print course number
        cout << courses[courseIndex].courseNumber;

        // Print course title
        cout << ", " << courses[courseIndex].courseTitle << endl;

        // Print list of prerequisites
        cout << "Prerequisites: ";

        // For i is 0 to size of prerequistes of the the specific course
        for (int i = 0; i < courses[courseIndex].prerequisites.size(); i++) {

            // Print the prerequistes
            cout << courses[courseIndex].prerequisites[i] << ", ";
        }
        cout << endl;
    }

    // Else print course not found
    else {
        cout << "Course not found!" << endl;
    }
}

// Create a function to load courses
void loadCourses(string filename) {

    // Declare variable
    string line;

    // Print loading txt file
    cout << "Loading TXT file..." << filename << endl;

    // Create an ifstream object called file that opens the filename
    ifstream file(filename);

    // If file failed to open
    if (!file) {

        // Print failed to open
        cout << "Failed to open file." << endl;

        // Return to cases
        return;
    }

    // Create a while loop that reads each line in the file
    while (getline(file, line)) {

        // Create an object stringstream ss for the line
        stringstream ss(line);

        // Declare course object course to store information
        Course course;

        // Declare variable token
        string token;

        // Get the course number and title using the first two tokens separated by commas
        getline(ss, token, ',');
        course.courseNumber = token;

        getline(ss, token, ',');
        course.courseTitle = token;

        // For the rest of the tokens add them to the prerequistes of the course
        while (getline(ss, token, ',')) {
            course.prerequisites.push_back(token);
        }

        // Add the course to the list of courses
        courses.push_back(course);
    }

    // Close file
    file.close();

    // Print file loaded successfully
    cout << "File loaded successfully!" << endl;
}

// Create a function that compares courses
bool compareCourses(const Course& course2, const Course& course1) {

    // Return the expression 
    return course2.courseNumber < course1.courseNumber;
}

// Create the function sortVectorAlphanumeric
void sortVectorAlphanumeric(vector<Course>& courses) {

    // For i is 0 to courses size
    for (int i = 0; i < courses.size() - 1; ++i) {

        // For j is 0 to courses size
        for (int j = 0; j < courses.size() - i - 1; ++j) {

            // If the second course courseNumber is less than the first course course Number
            if (compareCourses(courses[j + 1], courses[j])) {

                // Swap the courses
                swap(courses[j], courses[j + 1]);
            }
        }
    }
}


// Create a function to print course list
void printCourseList() {

    // Call the function sortVectorAlphanumeric
    sortVectorAlphanumeric(courses);

    // For i = 0 to courses size
    for (int i = 0; i < courses.size(); i++) {

        // Print course number and title
        cout << courses[i].courseNumber << ", " << courses[i].courseTitle << endl;
    }
}

// Main function
int main() {

    // Declare variables
    int choice;
    bool isDataLoaded = false;
    string filename;

    // Print menu
    cout << "Welcome to the course planner." << endl;
    cout << "1. Load Data Structure." << endl;
    cout << "2. Print Course List." << endl;
    cout << "3. Print Course." << endl;
    cout << "9. Exit" << endl;

    // Create a while loop
    while (true) {

        // Ask user for their menu option and store it in variable choice
        cout << "What would you like to do? ";
        cin >> choice;

        // Create case statements based on each menu option
        switch (choice) {

        // If menu option 1 is chosen
        case 1:

            // Set the filename
            cout << "Input filename with '.txt' included in the end: ";
            cin >> filename;

            // Call the function loadCourses
            loadCourses(filename);

            // Set isDataLoaded to true
            isDataLoaded = true;

            // Break
            break;

        // If menu option 2 is chosen
        case 2:

            // If isDataLoaded true
            if (isDataLoaded) {

                // Call the function printCourseList()
                printCourseList();
            }

            // Else print for the user to load the data first
            else {
                cout << "Please load the data from the file first. Select Option 1." << endl;
            }

            // Break
            break;

        // If the menu option is 3
        case 3:

            // If isDataLoaded true
            if (isDataLoaded) {

                // Declare variable
                string courseNumber;

                // Prompt user to enter a course number and store it in courseNumber
                cout << "Enter course number: ";
                cin >> courseNumber;

                // Call the function printCourseInformation
                printCourseInformation(courses, courseNumber);
            }

            // Else print for the user to load the data first
            else {
                cout << "Please load the data from the file first. Select Option 1." << endl;
            }

            // Break
            break;

        // If the menu option is 9
        case 9:

            // Print thank you for using course planner and exit
            cout << "Thank you for using the course planner!" << endl;
            return 0;

        // If the choice is anything than the previous options
        default:

            // Print wrong input
            cout << "Wrong input" << endl;
            
            // Break
            break;
        }
        cout << endl;
    }

    return 0;
}

