from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):

    def __init__(self):
        # Initialize Connection Variables
        USER = 'aacuser'
        PASS = 'SNHU2024'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31729
        DB = 'AAC'
        COL = 'animals'

        # Initialize Connection
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

    def create(self, dat):
        if dat:
            try:
                self.collection.insert_one(dat)
                return True
            except Exception as e:
                print("Error: ", e)
                return False
        else:
            print("Nothing to save, because data parameter is empty")
            return False

    def read(self, document):
        try:
            searchResult = self.collection.find(document)
            return list(searchResult)
        except Exception as e:
            print("Error: ", e)
            return []
        
    def update(self, document, dat):
        try: 
            updateResult = self. collection.update_many(document, {"$set": dat})
            return updateResult
        except Exception as e:
            print("Error: ", e)
            return []
        
    def delete(self, document):
        try:
            deleteResult = self.collection.delete_many(document)
            return deleteResult
        except Exception as e:
            print("Error: ", e)
        return 0
    
    def water_rescue_query(self):
        return {
            'Outcome Type': 'Water Rescue',
            'Breed': {'$in': ['Labrador Retriever Mix', 'Chesapeake Bay Retriever', 'Newfoundland']},
            'Sex upon Outcome': 'Intact Female',
            'Age upon Outcome in Weeks': {'$gte': 26, '$lte': 156}
        }

    def mountain_rescue_query(self):
        return {
            'Outcome Type': 'Mountain or Wilderness Rescue',
            'Breed': {'$in': ['German Shepherd', 'Alaskan Malamute', 'Old English Sheepdog', 'Siberian Husky', 'Rottweiler']},
            'Sex upon Outcome': 'Intact Male',
            'Age upon Outcome in Weeks': {'$gte': 26, '$lte': 156}
        }

    def disaster_rescue_query(self):
        return {
            'Outcome Type': 'Disaster or Individual Tracking',
            'Breed': {'$in': ['Doberman Pinscher', 'German Shepherd', 'Golden Retriever', 'Bloodhound', 'Rottweiler']},
            'Sex upon Outcome': 'Intact Male',
            'Age upon Outcome in Weeks': {'$gte': 20, '$lte': 300}
        }

