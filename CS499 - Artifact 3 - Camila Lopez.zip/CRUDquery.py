# CRUDquery.py

import pandas as pd

class AnimalShelter(object):
    def __init__(self, csv_file):
        # Initialize the DataFrame
        self.df = pd.read_csv(csv_file)

    def read(self, query):
        try:
            # Filtering the DataFrame based on the query dictionary
            df_filtered = self.df
            for key, value in query.items():
                if isinstance(value, dict):
                    if '$gte' in value:
                        df_filtered = df_filtered[df_filtered[key] >= value['$gte']]
                    if '$lte' in value:
                        df_filtered = df_filtered[df_filtered[key] <= value['$lte']]
                    if '$in' in value:
                        df_filtered = df_filtered[df_filtered[key].isin(value['$in'])]
                else:
                    df_filtered = df_filtered[df_filtered[key] == value]
            return df_filtered.to_dict('records')
        except Exception as e:
            print("Error: ", e)
            return []

    def water_rescue_query(self):
        return {
            'Outcome Type': 'Water Rescue',
            'breed': ['Labrador Retriever Mix', 'Chesapeake Bay Retriever', 'Newfoundland'],
            'sex_upon_outcome': 'Intact Female',
            'Age upon Outcome in Weeks': {'$gte': 26, '$lte': 156}
        }

    def mountain_rescue_query(self):
        return {
            'Outcome Type': 'Mountain or Wilderness Rescue',
            'Breed': ['German Shepherd', 'Alaskan Malamute', 'Old English Sheepdog', 'Siberian Husky', 'Rottweiler'],
            'Sex upon Outcome': 'Intact Male',
            'Age upon Outcome in Weeks': {'$gte': 26, '$lte': 156}
        }

    def disaster_rescue_query(self):
        return {
            'Outcome Type': 'Disaster or Individual Tracking',
            'Breed': ['Doberman Pinscher', 'German Shepherd', 'Golden Retriever', 'Bloodhound', 'Rottweiler'],
            'Sex upon Outcome': 'Intact Male',
            'Age upon Outcome in Weeks': {'$gte': 20, '$lte': 300}
        }

    def query(self, filters):
        query = {}
        if filters.get('animal_type'):
            query['Animal Type'] = filters['animal_type']
        if filters.get('breed'):
            query['Breed'] = filters['breed']
        if filters.get('age_min') is not None:
            query.setdefault('Age upon Outcome in Weeks', {})['$gte'] = filters['age_min']
        if filters.get('age_max') is not None:
            query.setdefault('Age upon Outcome in Weeks', {})['$lte'] = filters['age_max']
        if filters.get('name'):
            query['Name'] = filters['name']
        return self.read(query)
